The following are some of the headers deinied by ANSI Standard.

1) ctype.h
2) errno.h
3) float.h
4) math.h
5) limits.h

In limits.h file all compile-time limits are defined. These constants
are standard for a system.

Run the program ansilinits for details.

+++++++++++++++++++++++++++++++++++++
To Develop portable code we need to make use of compile time options,
compile time limits specfied by ANSI and POSIX and runtime limits of the
system on which our program is running.


++++++++++++++++++++++++++++++++++++++
Most of the examples in this are derived from Adv. Unix Programming.

