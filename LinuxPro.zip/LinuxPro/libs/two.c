/* lib test
 * Author : Team veda
 * 
*/

#include <stdio.h>
test1(){
	printf("\n%s: \n",__func__);
	printf(" test lib\n");
}
