#include <stdio.h>
int main()
{
	printf("\n%s: \n",__func__);
	liba();
	libb();
	return 0;
}
