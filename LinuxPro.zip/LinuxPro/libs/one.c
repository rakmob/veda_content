#include <stdio.h>
test(){
	printf("\n%s: \n",__func__);
	printf(" test lib\n");
}
