#include <semaphore.h>

struct mydata{
	sem_t mysem;
	int a;
	int b;
}; 
